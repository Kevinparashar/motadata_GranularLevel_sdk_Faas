"""
Motadata Python AI SDK

A comprehensive Python SDK for building AI-powered applications with
modular, swappable components.
"""

__version__ = "0.1.0"

